/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author USUARIO
 */
public class Catafinca {
    public String nombreFinca;
    public String ubicacion;
    public String nameEnca;
    public String cedulaEnca;
    public String telEnca;
    public int canrPotrero;
    public String sizeFinca;
    public int totalAnimales;
}
