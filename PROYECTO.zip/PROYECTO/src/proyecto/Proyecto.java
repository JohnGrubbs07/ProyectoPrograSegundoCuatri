/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto;

import javax.swing.JOptionPane;
public class Proyecto {

    public static void main(String[] args) {

        Cataganado[] ganadoArray = new Cataganado[10];

        String opcionMenu = "";
        int cantidad = 0;
        int intentos = 0;

        do {
            opcionMenu = JOptionPane.showInputDialog("""
                                                     ***BIENVENIDO AL MENU!**
                                                     Opcion 1= Desea ingresar informacion
                                                     Opcion 2= Desea modificar informacion
                                                     Opcion 3= Desea Eliminar la informacion
                                                     Opcion 4= Desea consultar la informacion
                                                     Opcion 5= Desea salir""");

            switch (opcionMenu) {

                case "1":
                    cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cuantos animales desea insertar:"));
                    intentos = 0;

                    do {
                        Cataganado c = new Cataganado();
                        c.setCodAnimal(Integer.parseInt(JOptionPane.showInputDialog("Cual es el codigo del ganado?:")));
                        c.setNombreAnimal(JOptionPane.showInputDialog(null, "Cual es el nombre del animal?:"));
                        c.setNacimiento(JOptionPane.showInputDialog(null, "Cuando nacio el animal?:"));
                        c.setPeso(JOptionPane.showInputDialog(null, "Cual es el ultimo peso registrado del ganado?:"));
                        c.setRazaAnimal(JOptionPane.showInputDialog(null, "De que raza es el animal?:"));
                        c.setSexoAnimal(JOptionPane.showInputDialog(null, "De que sexo es el ganado?:"));

                        ganadoArray[intentos] = c;
                        intentos++;

                    } while (intentos < cantidad);

                    break;

                case "2":
                    String MenuCambioInfo = "";
                    int opciones;
                    MenuCambioInfo = JOptionPane.showInputDialog("""
                                                                 ***BIENVENIDO AL MENU!**
                                                                 Opcion 1= Desea cambiar el codigo del animal
                                                                 Opcion 2= Desea cambiar el nombre del animal 
                                                                 Opcion 3= Desea cambiar la fecha de nacimiento del animal
                                                                 Opcion 4= Desea cambiar el peso del animal
                                                                 Opcion 5= Desea cambiar la raza del animal
                                                                 Opcion 6= Desea cambiar el sexo del animal
                                                                 Opcion 7= volver al menu anterior""");
                    
                    opciones = Integer.parseInt(JOptionPane.showInputDialog(MenuCambioInfo));
                    switch(opciones){
                        
                        case 1:
                        
                        int CodBuscar = Integer.parseInt(JOptionPane.showInputDialog("Cual es el dato a modificar:"));
                        int NuevoCod = Integer.parseInt(JOptionPane.showInputDialog("Cual es el nuevo codigo:"));
                        
                        for (int i = 0; i < ganadoArray.length; i++) {
                            if (ganadoArray[i] != null && ganadoArray[i].getCodAnimal() == CodBuscar) {
                                ganadoArray[i].setCodAnimal(NuevoCod);
                            }
                        }
                        break;
                        
                        case 2:
                            
                            String CodBuscar = JOptionPane.showInputDialog("Cual es el dato a modificar:");
                            String NuevoCod = JOptionPane.showInputDialog("Cual es el nuevo nombre:");
                            
                            for (int i = 0; i < ganadoArray.length; i++) {
                                if (ganadoArray[i] != null && ganadoArray[i].getNombreAnimal()== CodBuscar) {
                                    ganadoArray[i].setNombreAnimal(NuevoCod);
                                }
                            }
                            break;
                            
                        case 3: 
                            String CodBuscar = JOptionPane.showInputDialog("Cual es el dato a modificar:");
                            String NuevoCod = JOptionPane.showInputDialog("Cual es el nacimiento nuevo:");
                            
                            for (int i = 0; i < ganadoArray.length; i++) {
                                if (ganadoArray[i] != null && ganadoArray[i].getNacimiento()== CodBuscar) {
                                    ganadoArray[i].setNacimiento(NuevoCod);
                                }
                            }
                            break;
                            
                        case 4:
                            
                            String CodBuscar =JOptionPane.showInputDialog("Cual es el dato a modificar:");
                            String NuevoCod = JOptionPane.showInputDialog("Cual es el nuevo peso del animal:");
                            
                            for (int i = 0; i < ganadoArray.length; i++) {
                                if (ganadoArray[i] != null && ganadoArray[i].getPeso()== CodBuscar) {
                                    ganadoArray[i].setPeso(NuevoCod);
                                }
                            }
                            break;
                            
                        case 5: 
                            
                            String CodBuscar =JOptionPane.showInputDialog("Cual es el dato a modificar:");
                            String NuevoCod = JOptionPane.showInputDialog("Cual es la nueva raza del animal:");
                            
                            for (int i = 0; i < ganadoArray.length; i++) {
                                if (ganadoArray[i] != null && ganadoArray[i].getRazaAnimal()== CodBuscar) {
                                    ganadoArray[i].setRazaAnimal(NuevoCod);
                                }
                            } 
                            break;
                            
                        case 6:
                            
                            String CodBuscar =JOptionPane.showInputDialog("Cual es el dato a modificar:");
                            String NuevoCod = JOptionPane.showInputDialog("Cual es el nuevo sexo del animal:");
                            
                            for (int i = 0; i < ganadoArray.length; i++) {
                                if (ganadoArray[i] != null && (ganadoArray[i].getSexoAnimal() == null ? CodBuscar == null : ganadoArray[i].getSexoAnimal().equals(CodBuscar))) {
                                    ganadoArray[i].setSexoAnimal(NuevoCod);
                                }
                            }
                            break;
                        
                        case 7:
                            System.out.println("Ha solicitado regresar al menu anterior");
                         // Salta a la etiqueta menuPrincipal
                        
                        default:
                            System.out.println("\nOpcion no valida!");
                            
                            continue;
                    }
            }
                            break;
          
                   /* for (Cataganado ganado : ganadoArray) {
                        if (ganado != null) {
                            System.out.println("\nCódigo del animal: " + ganado.getCodAnimal()
                                    + "\nNombre del animal: " + ganado.getNombreAnimal()
                                    + "\nFecha de nacimiento del animal: " + ganado.getNacimiento()
                                    + "\nPeso del animal: " + ganado.getPeso()
                                    + "\nRaza del animal: " + ganado.getRazaAnimal()
                                    + "\nSexo del animal: " + ganado.getSexoAnimal());
                        }
                    }

                    int CodBuscar = Integer.parseInt(JOptionPane.showInputDialog("Cual es el dato a modificar:"));
                    int NuevoCod = Integer.parseInt(JOptionPane.showInputDialog("Cual es el nuevo codigo:"));
                    String NuevoNombre = JOptionPane.showInputDialog("Cual es el nuevo nombre:");

                    for (int i = 0; i < ganadoArray.length; i++) {
                        if (ganadoArray[i] != null && ganadoArray[i].getCodAnimal() == CodBuscar) {
                            ganadoArray[i].setCodAnimal(NuevoCod);
                                    ganadoArray[i].setNombreAnimal(NuevoNombre);*/
                            
                case "3":
                    // Implementa aquí el código para eliminar información del ganado
                    break;
                    
                case "4":
                    for (Cataganado ganado : ganadoArray) {
                        if (ganado != null) {
                            System.out.println("\nCódigo del animal: " + ganado.getCodAnimal()
                                    + "\nNombre del animal: " + ganado.getNombreAnimal()
                                    + "\nFecha de nacimiento del animal: " + ganado.getNacimiento()
                                    + "\nPeso del animal: " + ganado.getPeso()
                                    + "\nRaza del animal: " + ganado.getRazaAnimal()
                                    + "\nSexo del animal: " + ganado.getSexoAnimal());
                        }
                    }
                    break;

                case "5":
                    System.out.println("\nVuelve pronto ");
                    break;

                default:
                    System.out.println("\nOpcion no valida ");
            }

        }  while (!opcionMenu.equals("5"));


