/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author mac
 */


public class Cataganado {
    private int codAnimal;
    private String nombreAnimal;
    private String nacimiento;
    private String peso;
    private String sexoAnimal;
    private String razaAnimal;

    public Cataganado() {
    }

    public Cataganado(int codAnimal, String nombreAnimal, String nacimiento, String peso, String sexoAnimal, String razaAnimal) {
        this.codAnimal = codAnimal;
        this.nombreAnimal = nombreAnimal;
        this.nacimiento = nacimiento;
        this.peso = peso;
        this.sexoAnimal = sexoAnimal;
        this.razaAnimal = razaAnimal;
    }

    // Getters y setters (métodos para acceder a los atributos)

    public int getCodAnimal() {
        return codAnimal;
    }

    public void setCodAnimal(int codAnimal) {
        this.codAnimal = codAnimal;
    }

    public String getNombreAnimal() {
        return nombreAnimal;
    }

    public void setNombreAnimal(String nombreAnimal) {
        this.nombreAnimal = nombreAnimal;
    }

    public String getNacimiento() {
        return nacimiento;
    }

    public void setNacimiento(String nacimiento) {
        this.nacimiento = nacimiento;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getSexoAnimal() {
        return sexoAnimal;
    }

    public void setSexoAnimal(String sexoAnimal) {
        this.sexoAnimal = sexoAnimal;
    }

    public String getRazaAnimal() {
        return razaAnimal;
    }

    public void setRazaAnimal(String razaAnimal) {
        this.razaAnimal = razaAnimal;
    }
}
